document.querySelectorAll('.consultar').forEach(button => {
    button.addEventListener('click', function() {
        const target = this.getAttribute('data-target');
        const commentsSection = document.querySelector(target);
        commentsSection.scrollIntoView({ behavior: 'smooth' });
    });
});

document.querySelector('.toggle-terms').addEventListener('click', function() {
    const termsSection = document.getElementById('terminos');
    termsSection.style.display = termsSection.style.display === "none" ? "block" : "none";
});

document.querySelector('.close-terms').addEventListener('click', function() {
    document.getElementById('terminos').style.display = "none";
});

// Menú hamburguesa
document.querySelector('.menu-toggle').addEventListener('click', function() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('active');
});
